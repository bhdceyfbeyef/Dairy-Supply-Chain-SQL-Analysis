USE DairySupplyChainDB;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ============================================================
   Dairy Supply Chain SQL Capstone - Data Load
   Scenario: fictional Egyptian yoghurt manufacturing plant
   Data period: 2024-01-01 through 2026-08-31

   IMPORTANT
   - Run this file only after creating the 10 tables exactly as
     described in the project PDF.
   - IDs are supplied by this load file; they are not generated
     automatically.
   - The large fact tables are generated set-wise so the script
     stays compact while loading realistic volumes.
   ============================================================ */

IF EXISTS (SELECT 1 FROM Suppliers)
   OR EXISTS (SELECT 1 FROM Materials)
   OR EXISTS (SELECT 1 FROM Products)
   OR EXISTS (SELECT 1 FROM ProductionLines)
   OR EXISTS (SELECT 1 FROM PurchaseOrders)
   OR EXISTS (SELECT 1 FROM PurchaseOrderLines)
   OR EXISTS (SELECT 1 FROM ProductionBatches)
   OR EXISTS (SELECT 1 FROM BatchMaterialUsage)
   OR EXISTS (SELECT 1 FROM QualityInspections)
   OR EXISTS (SELECT 1 FROM Dispatches)
BEGIN
    THROW 50001, 'Load stopped: one or more project tables already contain data.', 1;
END;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    /* ========================================================
       1) SUPPLIERS - 45 rows
       ======================================================== */
    INSERT INTO Suppliers
    (
        SupplierID, SupplierCode, SupplierName, SupplierType,
        Governorate, LeadTimeDays, QualityRating, Status
    )
    VALUES
    (1,'SUP001','Green Valley Dairy Farm','Dairy Farm','Beheira',1,4.72,'Active'),
    (2,'SUP002','Delta Milk Cooperative','Dairy Farm','Dakahlia',1,4.55,'Active'),
    (3,'SUP003','Nile Meadows Farm','Dairy Farm','Gharbia',1,4.61,'Active'),
    (4,'SUP004','Al Safwa Dairy Estate','Dairy Farm','Sharqia',1,4.34,'Active'),
    (5,'SUP005','West Delta Milk Farm','Dairy Farm','Beheira',1,4.28,'Active'),
    (6,'SUP006','El Wadi Dairy Farm','Dairy Farm','Fayoum',1,4.42,'Active'),
    (7,'SUP007','Menoufia Fresh Milk Farm','Dairy Farm','Menoufia',1,4.18,'Active'),
    (8,'SUP008','Al Amal Dairy Farm','Dairy Farm','Giza',1,4.11,'Active'),
    (9,'SUP009','Beni Suef Milk Producers','Dairy Farm','Beni Suef',1,4.36,'Active'),
    (10,'SUP010','Royal Herd Dairy Farm','Dairy Farm','Sharqia',1,4.67,'Active'),
    (11,'SUP011','Delta Prime Milk Farm','Dairy Farm','Dakahlia',1,4.52,'Active'),
    (12,'SUP012','Al Nour Dairy Farm','Dairy Farm','Gharbia',1,4.09,'Active'),
    (13,'SUP013','Harvest Dairy Estate','Dairy Farm','Beheira',1,4.44,'Active'),
    (14,'SUP014','Fayoum Dairy Cooperative','Dairy Farm','Fayoum',1,4.03,'Active'),
    (15,'SUP015','Eastern Plains Dairy','Dairy Farm','Sharqia',1,4.39,'Active'),
    (16,'SUP016','Canal Dairy Farm','Dairy Farm','Ismailia',1,4.22,'Active'),
    (17,'SUP017','Upper Nile Dairy Farm','Dairy Farm','Minya',2,3.91,'Active'),
    (18,'SUP018','Golden Cow Dairy Farm','Dairy Farm','Menoufia',1,3.84,'Inactive'),

    (19,'SUP019','SweetSource Ingredients','Ingredient','Cairo',7,4.58,'Active'),
    (20,'SUP020','FermaTech Cultures','Ingredient','Cairo',14,4.79,'Active'),
    (21,'SUP021','FruitBlend Egypt','Ingredient','Alexandria',10,4.63,'Active'),
    (22,'SUP022','StabilMix Food Solutions','Ingredient','Giza',8,4.41,'Active'),
    (23,'SUP023','Delta Dairy Ingredients','Ingredient','Dakahlia',9,4.36,'Active'),
    (24,'SUP024','Nile Food Additives','Ingredient','Cairo',11,4.18,'Active'),
    (25,'SUP025','Mediterranean Fruit Prep','Ingredient','Alexandria',12,4.47,'Active'),
    (26,'SUP026','ProCulture Ingredients','Ingredient','Giza',15,4.74,'Active'),
    (27,'SUP027','SugarLine Supply','Ingredient','Gharbia',6,4.21,'Active'),
    (28,'SUP028','FoodBase Egypt','Ingredient','Cairo',8,4.05,'Active'),
    (29,'SUP029','Prime Dairy Powders','Ingredient','Alexandria',18,4.33,'Active'),
    (30,'SUP030','FlavorCraft Egypt','Ingredient','Giza',12,3.88,'Inactive'),

    (31,'SUP031','PackForm Egypt','Packaging','10th of Ramadan',7,4.62,'Active'),
    (32,'SUP032','Delta Cups Industries','Packaging','Sharqia',6,4.48,'Active'),
    (33,'SUP033','FlexSeal Packaging','Packaging','6th of October',8,4.57,'Active'),
    (34,'SUP034','CartonWorks Egypt','Packaging','Cairo',5,4.31,'Active'),
    (35,'SUP035','Nile Plastics Packaging','Packaging','Qalyubia',7,4.22,'Active'),
    (36,'SUP036','Prime Foil Industries','Packaging','Alexandria',9,4.51,'Active'),
    (37,'SUP037','SmartPack Solutions','Packaging','Giza',6,4.45,'Active'),
    (38,'SUP038','FreshCup Packaging','Packaging','Sharqia',5,4.28,'Active'),
    (39,'SUP039','BoxLine Industries','Packaging','Gharbia',6,4.17,'Active'),
    (40,'SUP040','Delta Label & Pack','Packaging','Dakahlia',7,4.13,'Active'),
    (41,'SUP041','ColdChain Pack Egypt','Packaging','Cairo',10,4.37,'Active'),
    (42,'SUP042','EcoPack Manufacturing','Packaging','Menoufia',8,4.26,'Active'),
    (43,'SUP043','SecureSeal Egypt','Packaging','Qalyubia',7,4.49,'Active'),
    (44,'SUP044','PalletPro Egypt','Packaging','Alexandria',12,4.04,'Active'),
    (45,'SUP045','ValuePack Industries','Packaging','Giza',9,3.82,'Inactive');

    /* ========================================================
       2) MATERIALS - 20 rows
       ======================================================== */
    INSERT INTO Materials
    (
        MaterialID, MaterialCode, MaterialName, MaterialCategory,
        UOM, StorageType, ShelfLifeDays, StandardCost, Status
    )
    VALUES
    (1,'MAT001','Raw Cow Milk','Raw Milk','L','Chilled',2,28.0000,'Active'),
    (2,'MAT002','Refined Sugar','Ingredient','KG','Ambient',730,38.0000,'Active'),
    (3,'MAT003','Skim Milk Powder','Ingredient','KG','Ambient',365,170.0000,'Active'),
    (4,'MAT004','Yoghurt Starter Culture','Culture','KG','Frozen',540,7500.0000,'Active'),
    (5,'MAT005','Stabilizer Blend','Ingredient','KG','Ambient',365,220.0000,'Active'),
    (6,'MAT006','Strawberry Fruit Preparation','Fruit Preparation','KG','Chilled',120,95.0000,'Active'),
    (7,'MAT007','Mango Fruit Preparation','Fruit Preparation','KG','Chilled',120,88.0000,'Active'),
    (8,'MAT008','Blueberry Fruit Preparation','Fruit Preparation','KG','Chilled',120,115.0000,'Active'),
    (9,'MAT009','Vanilla Flavor Concentrate','Flavor','KG','Ambient',365,650.0000,'Active'),
    (10,'MAT010','170g PP Cup','Packaging','PCS','Ambient',1095,1.2000,'Active'),
    (11,'MAT011','400g PP Tub','Packaging','PCS','Ambient',1095,2.3000,'Active'),
    (12,'MAT012','1kg PP Tub','Packaging','PCS','Ambient',1095,4.8000,'Active'),
    (13,'MAT013','95mm Foil Lid','Packaging','PCS','Ambient',1095,0.3800,'Active'),
    (14,'MAT014','120mm Foil Lid','Packaging','PCS','Ambient',1095,0.5500,'Active'),
    (15,'MAT015','150mm Foil Lid','Packaging','PCS','Ambient',1095,0.8000,'Active'),
    (16,'MAT016','Carton 12 x 170g','Packaging','PCS','Ambient',1095,7.5000,'Active'),
    (17,'MAT017','Carton 6 x 400g','Packaging','PCS','Ambient',1095,6.8000,'Active'),
    (18,'MAT018','Carton 6 x 1kg','Packaging','PCS','Ambient',1095,8.5000,'Active'),
    (19,'MAT019','Shrink Film','Packaging','KG','Ambient',730,72.0000,'Active'),
    (20,'MAT020','Food Grade Plastic Pallet','Packaging','PCS','Ambient',1825,380.0000,'Active');

    /* ========================================================
       3) PRODUCTS - 12 rows
       ======================================================== */
    INSERT INTO Products
    (
        ProductID, ProductCode, ProductName, ProductFamily, Flavor,
        PackSizeG, UnitsPerCase, TargetPH, ShelfLifeDays, Status
    )
    VALUES
    (1,'PRD001','Plain Set Yoghurt 170g','Set Yoghurt','Plain',170,12,4.45,21,'Active'),
    (2,'PRD002','Strawberry Set Yoghurt 170g','Set Yoghurt','Strawberry',170,12,4.45,21,'Active'),
    (3,'PRD003','Mango Set Yoghurt 170g','Set Yoghurt','Mango',170,12,4.45,21,'Active'),
    (4,'PRD004','Vanilla Set Yoghurt 170g','Set Yoghurt','Vanilla',170,12,4.45,21,'Active'),
    (5,'PRD005','Plain Stirred Yoghurt 400g','Stirred Yoghurt','Plain',400,6,4.40,21,'Active'),
    (6,'PRD006','Strawberry Stirred Yoghurt 400g','Stirred Yoghurt','Strawberry',400,6,4.40,21,'Active'),
    (7,'PRD007','Mango Stirred Yoghurt 400g','Stirred Yoghurt','Mango',400,6,4.40,21,'Active'),
    (8,'PRD008','Blueberry Stirred Yoghurt 400g','Stirred Yoghurt','Blueberry',400,6,4.40,21,'Active'),
    (9,'PRD009','Plain Family Yoghurt 1kg','Family Tub','Plain',1000,6,4.40,18,'Active'),
    (10,'PRD010','Strawberry Family Yoghurt 1kg','Family Tub','Strawberry',1000,6,4.40,18,'Active'),
    (11,'PRD011','Mango Family Yoghurt 1kg','Family Tub','Mango',1000,6,4.40,18,'Active'),
    (12,'PRD012','Vanilla Family Yoghurt 1kg','Family Tub','Vanilla',1000,6,4.40,18,'Active');

    /* ========================================================
       4) PRODUCTION LINES - 4 rows
       ======================================================== */
    INSERT INTO ProductionLines
    (
        LineID, LineCode, LineName, RatedCapacityKgPerHour, Status
    )
    VALUES
    (1,'YG01','Set Cup Line',5000.00,'Active'),
    (2,'YG02','Stirred Tub Line',6000.00,'Active'),
    (3,'YG03','Family Tub Line',7500.00,'Active'),
    (4,'YG04','Flexible Backup Line',4500.00,'Active');

    /* ========================================================
       Helper number table - up to 120,000 rows
       ======================================================== */
    ;WITH E1(N) AS
    (
        SELECT 1
        FROM (VALUES(0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) v(n)
    ),
    E2(N) AS (SELECT 1 FROM E1 a CROSS JOIN E1 b),
    E4(N) AS (SELECT 1 FROM E2 a CROSS JOIN E2 b),
    E6(N) AS (SELECT 1 FROM E4 a CROSS JOIN E2 b)
    SELECT TOP (120000)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS n
    INTO #Numbers
    FROM E6;

    CREATE UNIQUE CLUSTERED INDEX IX_Numbers_n ON #Numbers(n);

    /* ========================================================
       5) PURCHASE ORDERS - 30,000 rows
       ======================================================== */
    ;WITH POBase AS
    (
        SELECT
            n,
            CASE
                WHEN n <= 15000 THEN 1 + ((n - 1) % 18)
                WHEN n <= 22500 THEN 19 + ((n - 15001) % 12)
                ELSE 31 + ((n - 22501) % 15)
            END AS SupplierID,
            DATEADD
            (
                DAY,
                ((CHECKSUM(CONCAT('PO-DATE-', n)) & 2147483647) % 974),
                CAST('2024-01-01' AS date)
            ) AS PODate
        FROM #Numbers
        WHERE n <= 30000
    )
    INSERT INTO PurchaseOrders
    (
        POID, PONumber, SupplierID, PODate, ExpectedDate,
        POStatus, Currency, FreightCost
    )
    SELECT
        b.n AS POID,
        CONCAT('PO-', RIGHT('000000' + CAST(b.n AS varchar(6)), 6)) AS PONumber,
        b.SupplierID,
        b.PODate,
        DATEADD(DAY, s.LeadTimeDays + (b.n % 3), b.PODate) AS ExpectedDate,
        CASE
            WHEN b.n % 100 < 3 THEN 'Cancelled'
            WHEN b.n % 100 < 12 THEN 'Partial'
            ELSE 'Closed'
        END AS POStatus,
        CASE
            WHEN s.SupplierType = 'Dairy Farm' THEN 'EGP'
            WHEN s.SupplierType = 'Ingredient' AND b.n % 10 = 0 THEN 'EUR'
            WHEN s.SupplierType = 'Ingredient' AND b.n % 10 = 1 THEN 'USD'
            ELSE 'EGP'
        END AS Currency,
        CAST
        (
            CASE s.SupplierType
                WHEN 'Dairy Farm' THEN 500 + ((CHECKSUM(CONCAT('FREIGHT-F-', b.n)) & 2147483647) % 2201)
                WHEN 'Ingredient' THEN 1200 + ((CHECKSUM(CONCAT('FREIGHT-I-', b.n)) & 2147483647) % 6801)
                ELSE 900 + ((CHECKSUM(CONCAT('FREIGHT-P-', b.n)) & 2147483647) % 5101)
            END AS decimal(12,2)
        ) AS FreightCost
    FROM POBase b
    JOIN Suppliers s
        ON s.SupplierID = b.SupplierID;

    /* ========================================================
       6) PURCHASE ORDER LINES - 105,000 rows
       ======================================================== */
    ;WITH LineSource AS
    (
        SELECT
            po.POID,
            po.SupplierID,
            po.POStatus,
            s.SupplierType,
            L.LineNo,
            CASE
                WHEN s.SupplierType = 'Dairy Farm' THEN 1
                WHEN s.SupplierType = 'Ingredient' THEN 2 + ((po.POID + L.LineNo - 2) % 8)
                ELSE 10 + ((po.POID + L.LineNo - 2) % 11)
            END AS MaterialID
        FROM PurchaseOrders po
        JOIN Suppliers s
            ON s.SupplierID = po.SupplierID
        CROSS APPLY (VALUES(1),(2),(3),(4),(5),(6)) L(LineNo)
        WHERE s.SupplierType <> 'Dairy Farm'
           OR L.LineNo = 1
    ),
    QtyBase AS
    (
        SELECT
            ls.*,
            m.StandardCost,
            CAST
            (
                CASE
                    WHEN ls.MaterialID = 1 THEN 6000 + ((CHECKSUM(CONCAT('QTY-MILK-', ls.POID)) & 2147483647) % 24001)
                    WHEN ls.MaterialID = 2 THEN 800 + ((CHECKSUM(CONCAT('QTY-SUGAR-', ls.POID, '-', ls.LineNo)) & 2147483647) % 4201)
                    WHEN ls.MaterialID = 3 THEN 250 + ((CHECKSUM(CONCAT('QTY-SMP-', ls.POID, '-', ls.LineNo)) & 2147483647) % 1501)
                    WHEN ls.MaterialID = 4 THEN 5 + ((CHECKSUM(CONCAT('QTY-CULT-', ls.POID, '-', ls.LineNo)) & 2147483647) % 26)
                    WHEN ls.MaterialID = 5 THEN 100 + ((CHECKSUM(CONCAT('QTY-STAB-', ls.POID, '-', ls.LineNo)) & 2147483647) % 501)
                    WHEN ls.MaterialID BETWEEN 6 AND 9 THEN 300 + ((CHECKSUM(CONCAT('QTY-FRUIT-', ls.POID, '-', ls.LineNo)) & 2147483647) % 2401)
                    WHEN ls.MaterialID BETWEEN 10 AND 15 THEN 50000 + ((CHECKSUM(CONCAT('QTY-PACK-', ls.POID, '-', ls.LineNo)) & 2147483647) % 450001)
                    WHEN ls.MaterialID BETWEEN 16 AND 18 THEN 5000 + ((CHECKSUM(CONCAT('QTY-CARTON-', ls.POID, '-', ls.LineNo)) & 2147483647) % 45001)
                    WHEN ls.MaterialID = 19 THEN 500 + ((CHECKSUM(CONCAT('QTY-FILM-', ls.POID, '-', ls.LineNo)) & 2147483647) % 2501)
                    ELSE 50 + ((CHECKSUM(CONCAT('QTY-PALLET-', ls.POID, '-', ls.LineNo)) & 2147483647) % 451)
                END AS decimal(14,3)
            ) AS OrderedQty
        FROM LineSource ls
        JOIN Materials m
            ON m.MaterialID = ls.MaterialID
    )
    INSERT INTO PurchaseOrderLines
    (
        POLineID, POID, MaterialID, OrderedQty,
        ReceivedQty, UnitCost, LineStatus
    )
    SELECT
        ROW_NUMBER() OVER (ORDER BY q.POID, q.LineNo) AS POLineID,
        q.POID,
        q.MaterialID,
        q.OrderedQty,
        CAST
        (
            CASE
                WHEN q.POStatus = 'Cancelled' THEN 0
                WHEN q.POStatus = 'Partial' AND q.LineNo % 3 = 0
                    THEN q.OrderedQty * (0.55 + ((q.POID + q.LineNo) % 31) / 100.0)
                WHEN q.POStatus = 'Partial'
                    THEN q.OrderedQty * (0.98 + ((q.POID + q.LineNo) % 3) / 100.0)
                ELSE q.OrderedQty * (0.97 + ((q.POID + q.LineNo) % 4) / 100.0)
            END AS decimal(14,3)
        ) AS ReceivedQty,
        CAST
        (
            q.StandardCost *
            (0.94 + ((CHECKSUM(CONCAT('COST-', q.POID, '-', q.LineNo)) & 2147483647) % 15) / 100.0)
            AS decimal(12,4)
        ) AS UnitCost,
        CASE
            WHEN q.POStatus = 'Cancelled' THEN 'Cancelled'
            WHEN q.POStatus = 'Partial' AND q.LineNo % 3 = 0 THEN 'Partial'
            ELSE 'Received'
        END AS LineStatus
    FROM QtyBase q;

    /* ========================================================
       7) PRODUCTION BATCHES - 12,000 rows
       ======================================================== */
    ;WITH BatchBase AS
    (
        SELECT
            n AS BatchID,
            1 + ((CHECKSUM(CONCAT('PRODUCT-', n)) & 2147483647) % 12) AS ProductID,
            DATEADD
            (
                DAY,
                ((CHECKSUM(CONCAT('BATCH-DATE-', n)) & 2147483647) % 974),
                CAST('2024-01-01' AS date)
            ) AS ProductionDate,
            CAST(3000 + ((CHECKSUM(CONCAT('PLAN-KG-', n)) & 2147483647) % 12001) AS decimal(14,2)) AS PlannedQtyKg
        FROM #Numbers
        WHERE n <= 12000
    ),
    BatchCalc AS
    (
        SELECT
            b.*,
            p.PackSizeG,
            CASE
                WHEN b.BatchID % 10 = 0 THEN 4
                WHEN p.PackSizeG = 170 THEN 1
                WHEN p.PackSizeG = 400 THEN 2
                ELSE 3
            END AS LineID,
            DATEADD(HOUR, (b.BatchID % 4) * 6, CAST(b.ProductionDate AS datetime2)) AS StartDateTime
        FROM BatchBase b
        JOIN Products p
            ON p.ProductID = b.ProductID
    )
    INSERT INTO ProductionBatches
    (
        BatchID, BatchCode, ProductID, LineID, ProductionDate,
        PlannedQtyKg, ActualQtyKg, RejectQtyKg,
        StartDateTime, EndDateTime, BatchStatus
    )
    SELECT
        b.BatchID,
        CONCAT('B-', RIGHT('000000' + CAST(b.BatchID AS varchar(6)), 6)) AS BatchCode,
        b.ProductID,
        b.LineID,
        b.ProductionDate,
        b.PlannedQtyKg,
        CAST
        (
            b.PlannedQtyKg *
            (0.955 + ((CHECKSUM(CONCAT('ACTUAL-', b.BatchID)) & 2147483647) % 51) / 1000.0)
            AS decimal(14,2)
        ) AS ActualQtyKg,
        CAST
        (
            b.PlannedQtyKg *
            (0.002 + ((CHECKSUM(CONCAT('REJECT-', b.BatchID)) & 2147483647) % 26) / 1000.0)
            AS decimal(14,2)
        ) AS RejectQtyKg,
        b.StartDateTime,
        DATEADD(HOUR, 4 + (b.BatchID % 4), b.StartDateTime) AS EndDateTime,
        CASE
            WHEN b.BatchID % 100 < 2 THEN 'Rejected'
            WHEN b.BatchID % 100 < 6 THEN 'On Hold'
            ELSE 'Released'
        END AS BatchStatus
    FROM BatchCalc b;

    /* ========================================================
       8) BATCH MATERIAL USAGE - about 117,000 rows
       ======================================================== */
    ;WITH UsageSlots AS
    (
        SELECT
            pb.BatchID,
            pb.ProductID,
            pb.ProductionDate,
            pb.PlannedQtyKg,
            p.Flavor,
            p.PackSizeG,
            p.UnitsPerCase,
            S.SlotNo,
            CASE S.SlotNo
                WHEN 1 THEN 1
                WHEN 2 THEN 2
                WHEN 3 THEN 3
                WHEN 4 THEN 4
                WHEN 5 THEN 5
                WHEN 6 THEN CASE p.Flavor
                                WHEN 'Strawberry' THEN 6
                                WHEN 'Mango' THEN 7
                                WHEN 'Blueberry' THEN 8
                                WHEN 'Vanilla' THEN 9
                             END
                WHEN 7 THEN CASE p.PackSizeG WHEN 170 THEN 10 WHEN 400 THEN 11 ELSE 12 END
                WHEN 8 THEN CASE p.PackSizeG WHEN 170 THEN 13 WHEN 400 THEN 14 ELSE 15 END
                WHEN 9 THEN CASE p.PackSizeG WHEN 170 THEN 16 WHEN 400 THEN 17 ELSE 18 END
                WHEN 10 THEN 19
            END AS MaterialID
        FROM ProductionBatches pb
        JOIN Products p
            ON p.ProductID = pb.ProductID
        CROSS APPLY (VALUES(1),(2),(3),(4),(5),(6),(7),(8),(9),(10)) S(SlotNo)
        WHERE NOT (S.SlotNo = 6 AND p.Flavor = 'Plain')
    ),
    UsagePlanned AS
    (
        SELECT
            u.*,
            m.MaterialCode,
            m.StandardCost,
            CAST
            (
                CASE u.SlotNo
                    WHEN 1 THEN u.PlannedQtyKg * 0.93
                    WHEN 2 THEN u.PlannedQtyKg * 0.055
                    WHEN 3 THEN u.PlannedQtyKg * 0.025
                    WHEN 4 THEN u.PlannedQtyKg * 0.00025
                    WHEN 5 THEN u.PlannedQtyKg * 0.004
                    WHEN 6 THEN CASE WHEN u.Flavor = 'Vanilla' THEN u.PlannedQtyKg * 0.0015
                                     ELSE u.PlannedQtyKg * 0.10 END
                    WHEN 7 THEN (u.PlannedQtyKg * 1000.0) / u.PackSizeG
                    WHEN 8 THEN (u.PlannedQtyKg * 1000.0) / u.PackSizeG
                    WHEN 9 THEN ((u.PlannedQtyKg * 1000.0) / u.PackSizeG) / u.UnitsPerCase
                    WHEN 10 THEN u.PlannedQtyKg * 0.0015
                END AS decimal(14,3)
            ) AS PlannedQty
        FROM UsageSlots u
        JOIN Materials m
            ON m.MaterialID = u.MaterialID
    )
    INSERT INTO BatchMaterialUsage
    (
        UsageID, BatchID, MaterialID, MaterialLotNo,
        PlannedQty, ActualQty, WasteQty, UnitCost
    )
    SELECT
        ROW_NUMBER() OVER (ORDER BY u.BatchID, u.SlotNo) AS UsageID,
        u.BatchID,
        u.MaterialID,
        CONCAT
        (
            'LOT-',
            RIGHT('000' + CAST(u.MaterialID AS varchar(3)), 3), '-',
            CONVERT(char(6), u.ProductionDate, 12), '-',
            RIGHT('0000' + CAST(u.BatchID % 10000 AS varchar(4)), 4)
        ) AS MaterialLotNo,
        u.PlannedQty,
        CAST
        (
            u.PlannedQty *
            (0.985 + ((CHECKSUM(CONCAT('USE-', u.BatchID, '-', u.SlotNo)) & 2147483647) % 41) / 1000.0)
            AS decimal(14,3)
        ) AS ActualQty,
        CAST
        (
            u.PlannedQty *
            (0.001 + ((CHECKSUM(CONCAT('WASTE-', u.BatchID, '-', u.SlotNo)) & 2147483647) % 15) / 1000.0)
            AS decimal(14,3)
        ) AS WasteQty,
        CAST
        (
            u.StandardCost *
            (0.97 + ((CHECKSUM(CONCAT('UCOST-', u.BatchID, '-', u.SlotNo)) & 2147483647) % 9) / 100.0)
            AS decimal(12,4)
        ) AS UnitCost
    FROM UsagePlanned u;

    /* ========================================================
       9) QUALITY INSPECTIONS - 100,000 rows
       ======================================================== */
    ;WITH InspectionBase AS
    (
        SELECT
            n AS InspectionID,
            CASE
                WHEN n <= 30000 THEN 'IncomingMilk'
                WHEN n <= 65000 THEN 'InProcess'
                ELSE 'FinishedProduct'
            END AS InspectionType,
            CASE
                WHEN n <= 30000 THEN 1 + ((CHECKSUM(CONCAT('QC-SUP-', n)) & 2147483647) % 18)
                ELSE NULL
            END AS SupplierID,
            CASE
                WHEN n <= 30000 THEN NULL
                ELSE 1 + ((CHECKSUM(CONCAT('QC-BATCH-', n)) & 2147483647) % 12000)
            END AS BatchID
        FROM #Numbers
        WHERE n <= 100000
    ),
    InspectionValues AS
    (
        SELECT
            i.*,
            CASE
                WHEN i.InspectionType = 'IncomingMilk'
                    THEN DATEADD
                         (
                            MINUTE,
                            ((CHECKSUM(CONCAT('QC-TIME-', i.InspectionID)) & 2147483647) % 1440),
                            CAST(DATEADD(DAY, ((CHECKSUM(CONCAT('QC-DATE-', i.InspectionID)) & 2147483647) % 974), CAST('2024-01-01' AS date)) AS datetime2)
                         )
                ELSE DATEADD
                     (
                        MINUTE,
                        CASE WHEN i.InspectionType = 'InProcess' THEN 120 ELSE 360 END
                        + ((CHECKSUM(CONCAT('QC-OFFSET-', i.InspectionID)) & 2147483647) % 90),
                        pb.StartDateTime
                     )
            END AS InspectionDateTime,
            CAST
            (
                CASE
                    WHEN i.InspectionType = 'IncomingMilk' AND i.InspectionID % 40 = 0
                        THEN 8.2 + (i.InspectionID % 18) / 10.0
                    WHEN i.InspectionType = 'IncomingMilk'
                        THEN 2.5 + ((CHECKSUM(CONCAT('TEMP-IN-', i.InspectionID)) & 2147483647) % 41) / 10.0
                    WHEN i.InspectionType = 'InProcess'
                        THEN 40.0 + ((CHECKSUM(CONCAT('TEMP-IP-', i.InspectionID)) & 2147483647) % 51) / 10.0
                    WHEN i.InspectionID % 50 = 0
                        THEN 8.0 + (i.InspectionID % 16) / 10.0
                    ELSE 3.5 + ((CHECKSUM(CONCAT('TEMP-FP-', i.InspectionID)) & 2147483647) % 36) / 10.0
                END AS decimal(4,1)
            ) AS TemperatureC,
            CAST
            (
                CASE
                    WHEN i.InspectionType = 'IncomingMilk' AND i.InspectionID % 55 = 0
                        THEN 6.48 + (i.InspectionID % 5) / 100.0
                    WHEN i.InspectionType = 'IncomingMilk'
                        THEN 6.60 + ((CHECKSUM(CONCAT('PH-IN-', i.InspectionID)) & 2147483647) % 21) / 100.0
                    WHEN i.InspectionType = 'InProcess'
                        THEN 4.20 + ((CHECKSUM(CONCAT('PH-IP-', i.InspectionID)) & 2147483647) % 51) / 100.0
                    ELSE 4.20 + ((CHECKSUM(CONCAT('PH-FP-', i.InspectionID)) & 2147483647) % 36) / 100.0
                END AS decimal(3,2)
            ) AS PHValue,
            CAST
            (
                CASE
                    WHEN i.InspectionType = 'IncomingMilk'
                        THEN 3.20 + ((CHECKSUM(CONCAT('FAT-IN-', i.InspectionID)) & 2147483647) % 111) / 100.0
                    ELSE 2.60 + ((CHECKSUM(CONCAT('FAT-OUT-', i.InspectionID)) & 2147483647) % 81) / 100.0
                END AS decimal(4,2)
            ) AS FatPct,
            CASE
                WHEN i.InspectionType = 'IncomingMilk' AND i.InspectionID % 25 = 0
                    THEN 120000 + ((CHECKSUM(CONCAT('BAC-HIGH-', i.InspectionID)) & 2147483647) % 70001)
                WHEN i.InspectionType = 'IncomingMilk'
                    THEN 20000 + ((CHECKSUM(CONCAT('BAC-IN-', i.InspectionID)) & 2147483647) % 76001)
                ELSE 100 + ((CHECKSUM(CONCAT('BAC-OUT-', i.InspectionID)) & 2147483647) % 4901)
            END AS BacteriaCountCFU
        FROM InspectionBase i
        LEFT JOIN ProductionBatches pb
            ON pb.BatchID = i.BatchID
    ),
    InspectionResult AS
    (
        SELECT
            v.*,
            CASE
                WHEN v.InspectionType = 'IncomingMilk'
                     AND (v.TemperatureC > 8.0 OR v.PHValue < 6.55 OR v.PHValue > 6.85 OR v.BacteriaCountCFU > 100000)
                    THEN 'Fail'
                WHEN v.InspectionType = 'IncomingMilk'
                     AND (v.TemperatureC > 6.0 OR v.BacteriaCountCFU >= 80000)
                    THEN 'Hold'
                WHEN v.InspectionType = 'IncomingMilk'
                    THEN 'Pass'
                WHEN v.InspectionType = 'InProcess'
                     AND (v.TemperatureC < 39.0 OR v.TemperatureC > 46.0 OR v.PHValue < 4.15 OR v.PHValue > 4.70)
                    THEN 'Fail'
                WHEN v.InspectionType = 'InProcess' AND v.PHValue > 4.60
                    THEN 'Hold'
                WHEN v.InspectionType = 'InProcess'
                    THEN 'Pass'
                WHEN v.InspectionType = 'FinishedProduct'
                     AND (v.TemperatureC > 8.0 OR v.PHValue < 4.15 OR v.PHValue > 4.55)
                    THEN 'Fail'
                WHEN v.InspectionType = 'FinishedProduct'
                     AND (v.TemperatureC > 7.0 OR v.PHValue > 4.50)
                    THEN 'Hold'
                ELSE 'Pass'
            END AS Result
        FROM InspectionValues v
    )
    INSERT INTO QualityInspections
    (
        InspectionID, InspectionType, SupplierID, BatchID,
        InspectionDateTime, TemperatureC, PHValue, FatPct,
        BacteriaCountCFU, Result, InspectorCode, Notes
    )
    SELECT
        r.InspectionID,
        r.InspectionType,
        r.SupplierID,
        r.BatchID,
        r.InspectionDateTime,
        r.TemperatureC,
        r.PHValue,
        r.FatPct,
        r.BacteriaCountCFU,
        r.Result,
        CONCAT('QC', RIGHT('000' + CAST(1 + (r.InspectionID % 25) AS varchar(3)), 3)) AS InspectorCode,
        CASE r.Result
            WHEN 'Fail' THEN 'Result outside release limits - investigation required'
            WHEN 'Hold' THEN 'Borderline result - pending quality review'
            ELSE NULL
        END AS Notes
    FROM InspectionResult r;

    /* ========================================================
       10) DISPATCHES - 100,000 rows
       ======================================================== */
    ;WITH DispatchBase AS
    (
        SELECT
            n AS DispatchID,
            1 + ((CHECKSUM(CONCAT('DSP-BATCH-', n)) & 2147483647) % 12000) AS BatchID
        FROM #Numbers
        WHERE n <= 100000
    ),
    DispatchValues AS
    (
        SELECT
            d.DispatchID,
            d.BatchID,
            DATEADD
            (
                HOUR,
                6 + (d.DispatchID % 10),
                DATEADD(DAY, 1 + (d.DispatchID % 5), pb.EndDateTime)
            ) AS DispatchDateTime,
            CASE d.DispatchID % 12
                WHEN 0 THEN 'Cairo'
                WHEN 1 THEN 'Giza'
                WHEN 2 THEN 'Alexandria'
                WHEN 3 THEN 'Sharqia'
                WHEN 4 THEN 'Dakahlia'
                WHEN 5 THEN 'Gharbia'
                WHEN 6 THEN 'Beheira'
                WHEN 7 THEN 'Ismailia'
                WHEN 8 THEN 'Suez'
                WHEN 9 THEN 'Minya'
                WHEN 10 THEN 'Assiut'
                ELSE 'Sohag'
            END AS DestinationGovernorate,
            CASE d.DispatchID % 10
                WHEN 0 THEN 'Delta Fresh Distribution'
                WHEN 1 THEN 'Cairo Cold Chain Co.'
                WHEN 2 THEN 'Nile Food Logistics'
                WHEN 3 THEN 'Mediterranean Distribution'
                WHEN 4 THEN 'Upper Egypt Food Service'
                WHEN 5 THEN 'Canal Markets Supply'
                WHEN 6 THEN 'FreshRoute Egypt'
                WHEN 7 THEN 'Prime Grocery Distribution'
                WHEN 8 THEN 'CityMart Supply Network'
                ELSE 'Family Foods Distribution'
            END AS DistributorName,
            20 + ((CHECKSUM(CONCAT('CASE-QTY-', d.DispatchID)) & 2147483647) % 381) AS QuantityCases,
            CONCAT('RF-', RIGHT('000' + CAST(1 + (d.DispatchID % 80) AS varchar(3)), 3)) AS TruckCode,
            CAST
            (
                CASE
                    WHEN d.DispatchID % 50 = 0
                        THEN 8.1 + (d.DispatchID % 19) / 10.0
                    ELSE 3.0 + ((CHECKSUM(CONCAT('DSP-TEMP-', d.DispatchID)) & 2147483647) % 36) / 10.0
                END AS decimal(4,1)
            ) AS DispatchTemperatureC
        FROM DispatchBase d
        JOIN ProductionBatches pb
            ON pb.BatchID = d.BatchID
    )
    INSERT INTO Dispatches
    (
        DispatchID, DispatchNumber, BatchID, DispatchDateTime,
        DestinationGovernorate, DistributorName, QuantityCases,
        TruckCode, DispatchTemperatureC, DeliveryStatus
    )
    SELECT
        d.DispatchID,
        CONCAT('DSP-', RIGHT('000000' + CAST(d.DispatchID AS varchar(6)), 6)) AS DispatchNumber,
        d.BatchID,
        d.DispatchDateTime,
        d.DestinationGovernorate,
        d.DistributorName,
        d.QuantityCases,
        d.TruckCode,
        d.DispatchTemperatureC,
        CASE
            WHEN d.DispatchTemperatureC > 8.0 AND d.DispatchID % 2 = 0 THEN 'Returned'
            WHEN d.DispatchTemperatureC > 8.0 THEN 'RejectedAtDestination'
            WHEN d.DispatchID % 100 < 3 THEN 'Returned'
            ELSE 'Delivered'
        END AS DeliveryStatus
    FROM DispatchValues d;

    DROP TABLE #Numbers;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* ============================================================
   Verification
   ============================================================ */
SELECT 'Suppliers' AS TableName, COUNT(*) AS TotalRows FROM Suppliers
UNION ALL SELECT 'Materials', COUNT(*) FROM Materials
UNION ALL SELECT 'Products', COUNT(*) FROM Products
UNION ALL SELECT 'ProductionLines', COUNT(*) FROM ProductionLines
UNION ALL SELECT 'PurchaseOrders', COUNT(*) FROM PurchaseOrders
UNION ALL SELECT 'PurchaseOrderLines', COUNT(*) FROM PurchaseOrderLines
UNION ALL SELECT 'ProductionBatches', COUNT(*) FROM ProductionBatches
UNION ALL SELECT 'BatchMaterialUsage', COUNT(*) FROM BatchMaterialUsage
UNION ALL SELECT 'QualityInspections', COUNT(*) FROM QualityInspections
UNION ALL SELECT 'Dispatches', COUNT(*) FROM Dispatches;
GO
