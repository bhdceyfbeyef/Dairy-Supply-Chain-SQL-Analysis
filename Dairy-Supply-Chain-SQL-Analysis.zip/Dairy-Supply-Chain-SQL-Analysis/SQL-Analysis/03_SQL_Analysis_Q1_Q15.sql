/* q 1*/

select *
from suppliers
where governorate='Beheira' 
         OR Governorate = 'Sharqia'
         OR Governorate = 'Dakahlia'
and qualityRating >= 4.30


/* q2*/
select
* from materials
where shelflifedays <= 180

/*q3*/
select *
from products
where  PackSizeG=170
or  PackSizeG=400

-- =========================================================
-- Q4 - Purchase Orders
-- =========================================================

SELECT
    po.PONumber,
    po.PODate,
    po.ExpectedDate,
    s.SupplierName,
    s.SupplierType,
    po.POStatus,
    po.Currency,
    po.FreightCost
FROM PurchaseOrders AS po
 JOIN Suppliers AS s
    ON po.SupplierID = s.SupplierID
WHERE po.PODate >= '2026-04-01'
  and po.PODate != '2026-07-01'
  AND po.POStatus IN ('Closed', 'Partial')
ORDER BY po.PODate DESC
/*q5*/
SELECT TOP 20
    po.PONumber,
    m.MaterialName,
    pol.OrderedQty,
    pol.UnitCost,
    pol.OrderedQty * pol.UnitCost AS LineValue
FROM PurchaseOrderLines AS pol
 JOIN PurchaseOrders AS po
    ON pol.POID = po.POID
 JOIN Materials AS m
    ON pol.MaterialID = m.MaterialID
ORDER BY LineValue DESC
/*q6*/
SELECT
    pb.BatchCode,
    p.ProductName,
    pl.LineCode,
    pb.PlannedQtyKg,
    pb.ActualQtyKg,
    pb.RejectQtyKg,

    pb.ActualQtyKg * 100.0 / NULLIF(pb.PlannedQtyKg, 0)
        AS YieldPct,

    pb.RejectQtyKg * 100.0 / NULLIF(pb.ActualQtyKg, 0)
        AS RejectRatePct

FROM ProductionBatches AS pb
 JOIN Products AS p
    ON pb.ProductID = p.ProductID
 JOIN ProductionLines AS pl
    ON pb.LineID = pl.LineID

WHERE pb.BatchStatus = 'Released'
  AND pb.ProductionDate >= '2026-08-01'
  AND pb.ProductionDate < '2026-09-01'

ORDER BY YieldPct DESC
-- =========================================================
-- Q7 - Cold Dispatch Review
-- =========================================================

SELECT
    d.DispatchNumber,
    d.DispatchDateTime,
    p.ProductName,
    d.DestinationGovernorate,
    d.QuantityCases,
    d.TruckCode,
    d.DispatchTemperatureC

FROM Dispatches AS d
 JOIN ProductionBatches AS pb
    ON d.BatchID = pb.BatchID
 JOIN Products AS p
    ON pb.ProductID = p.ProductID

WHERE d.DeliveryStatus = 'Delivered'
  AND d.DestinationGovernorate IN ('Cairo', 'Giza', 'Alexandria')
  AND d.DispatchDateTime >= '2026-07-01'
  AND d.DispatchDateTime < '2026-09-01'

ORDER BY d.DispatchDateTime DESC
-- =========================================================
-- Q8 - Supplier Procurement Summary
-- =========================================================

SELECT
    s.SupplierID,
    s.SupplierCode,
    s.SupplierName,

    COUNT(DISTINCT po.POID) AS NumberOfPOs,

    SUM(pol.OrderedQty * pol.UnitCost) AS TotalProcurementValue,

    AVG(po.FreightCost) AS AverageFreightCost

FROM Suppliers AS s

 JOIN PurchaseOrders AS po
    ON s.SupplierID = po.SupplierID

JOIN PurchaseOrderLines AS pol
    ON po.POID = pol.POID

WHERE po.PODate >= '2026-01-01'
  AND po.PODate < '2027-01-01'

GROUP BY
    s.SupplierID,
    s.SupplierCode,
    s.SupplierName

HAVING COUNT(DISTINCT po.POID) >= 10

ORDER BY TotalProcurementValue DESC;
-- =========================================================
-- Q9 - Material Fill Rate
-- =========================================================

SELECT
    m.MaterialID,
    m.MaterialCode,
    m.MaterialName,

    COUNT(*) AS PurchaseLineCount,

    SUM(pol.OrderedQty) AS TotalOrderedQty,

    SUM(pol.ReceivedQty) AS TotalReceivedQty,

    SUM(pol.ReceivedQty) * 100.0
        / NULLIF(SUM(pol.OrderedQty), 0) AS FillRatePct

FROM Materials AS m

INNER JOIN PurchaseOrderLines AS pol
    ON m.MaterialID = pol.MaterialID

INNER JOIN PurchaseOrders AS po
    ON pol.POID = po.POID

WHERE pol.LineStatus <> 'Cancelled'

GROUP BY
    m.MaterialID,
    m.MaterialCode,
    m.MaterialName

HAVING COUNT(*) >= 20
   AND SUM(pol.ReceivedQty) * 100.0
       / NULLIF(SUM(pol.OrderedQty), 0) < 95

ORDER BY FillRatePct ASC;
-- =========================================================
-- Q10 - Product Family Production
-- =========================================================

SELECT
    p.ProductFamily,

    COUNT(pb.BatchID) AS TotalBatches,

    SUM(pb.PlannedQtyKg) AS TotalPlannedKg,

    SUM(pb.ActualQtyKg) AS TotalActualKg,

    SUM(pb.RejectQtyKg) AS TotalRejectKg,

    SUM(pb.ActualQtyKg) * 100.0
        / NULLIF(SUM(pb.PlannedQtyKg), 0) AS YieldPct

FROM ProductionBatches AS pb

 JOIN Products AS p
    ON pb.ProductID = p.ProductID

WHERE pb.ProductionDate >= '2026-04-01'
  AND pb.ProductionDate < '2026-07-01'

GROUP BY p.ProductFamily

ORDER BY TotalActualKg DESC;

-- =========================================================
-- Q11 - Raw Milk Supplier Quality
-- =========================================================

SELECT
    s.SupplierID,
    s.SupplierCode,
    s.SupplierName,

    COUNT(qi.InspectionID) AS TotalInspections,

    SUM(CASE
            WHEN qi.Result = 'Fail' THEN 1
            ELSE 0
        END) AS FailedInspections,

    SUM(CASE
            WHEN qi.Result = 'Hold' THEN 1
            ELSE 0
        END) AS HoldInspections,

    SUM(CASE
            WHEN qi.Result = 'Fail' THEN 1
            ELSE 0
        END) * 100.0
        / NULLIF(COUNT(qi.InspectionID), 0) AS FailRatePct,

    AVG(qi.TemperatureC) AS AverageTemperatureC,

    AVG(CAST(qi.BacteriaCountCFU AS DECIMAL(18,2)))
        AS AverageBacteriaCountCFU

FROM Suppliers AS s

INNER JOIN QualityInspections AS qi
    ON s.SupplierID = qi.SupplierID

WHERE s.SupplierType = 'Dairy Farm'
  AND qi.InspectionType = 'IncomingMilk'

GROUP BY
    s.SupplierID,
    s.SupplierCode,
    s.SupplierName

HAVING COUNT(qi.InspectionID) >= 100

ORDER BY FailRatePct DESC;
-- =========================================================
-- Q12
- Products Above the Overall Reject Benchmark
-- =========================================================

SELECT
    ProductID,
    ProductName,
    AverageRejectRatePct

FROM
(
    SELECT
        p.ProductID,
        p.ProductName,

        AVG(
            pb.RejectQtyKg * 100.0
            / NULLIF(pb.ActualQtyKg, 0)
        ) AS AverageRejectRatePct

    FROM Products AS p

    INNER JOIN ProductionBatches AS pb
        ON p.ProductID = pb.ProductID

    GROUP BY
        p.ProductID,
        p.ProductName
) AS ProductSummary

WHERE AverageRejectRatePct >
(
    SELECT AVG(AverageRejectRatePct)
    FROM
    (
        SELECT
            pb.ProductID,

            AVG(
                pb.RejectQtyKg * 100.0
                / NULLIF(pb.ActualQtyKg, 0)
            ) AS AverageRejectRatePct

        FROM ProductionBatches AS pb

        GROUP BY pb.ProductID
    ) AS ProductRates
)

ORDER BY AverageRejectRatePct DESC
-- =========================================================
-- Q13 - Materials Above Average Purchase Value
-- =========================================================

SELECT
    m.MaterialID,
    m.MaterialCode,
    m.MaterialName,

    SUM(pol.OrderedQty * pol.UnitCost) AS TotalPurchaseValue

FROM Materials AS m

INNER JOIN PurchaseOrderLines AS pol
    ON m.MaterialID = pol.MaterialID

INNER JOIN PurchaseOrders AS po
    ON pol.POID = po.POID

WHERE po.PODate >= '2026-01-01'
  AND po.PODate < '2027-01-01'

GROUP BY
    m.MaterialID,
    m.MaterialCode,
    m.MaterialName

HAVING SUM(pol.OrderedQty * pol.UnitCost) >
(
    SELECT AVG(TotalPurchaseValue)
    FROM
    (
        SELECT
            pol2.MaterialID,
            SUM(pol2.OrderedQty * pol2.UnitCost)
                AS TotalPurchaseValue

        FROM PurchaseOrderLines AS pol2

        INNER JOIN PurchaseOrders AS po2
            ON pol2.POID = po2.POID

        WHERE po2.PODate >= '2026-01-01'
          AND po2.PODate < '2027-01-01'

        GROUP BY pol2.MaterialID
    ) AS MaterialTotals
)

ORDER BY TotalPurchaseValue DESC

-- =========================================================
-- Q14 - High-Output Months
-- =========================================================

WITH MonthlyProduction AS
(
    SELECT
        DATEFROMPARTS(
            YEAR(ProductionDate),
            MONTH(ProductionDate),
            1
        ) AS MonthStart,

        COUNT(BatchID) AS BatchCount,

        SUM(PlannedQtyKg) AS TotalPlannedKg,

        SUM(ActualQtyKg) AS TotalActualKg,

        SUM(RejectQtyKg) AS TotalRejectKg

    FROM ProductionBatches

    WHERE ProductionDate >= '2026-01-01'
      AND ProductionDate < '2027-01-01'

    GROUP BY
        YEAR(ProductionDate),
        MONTH(ProductionDate)
)

SELECT
    MonthStart,
    BatchCount,
    TotalPlannedKg,
    TotalActualKg,
    TotalRejectKg

FROM MonthlyProduction

WHERE TotalActualKg >
(
    SELECT AVG(TotalActualKg)
    FROM MonthlyProduction
)

ORDER BY TotalActualKg DESC;







-- =========================================================
-- Q15 - Dairy Supplier Performance
-- =========================================================

WITH DairyProcurement AS
(
    SELECT
        s.SupplierID,
        s.SupplierName,

        SUM(pol.OrderedQty * pol.UnitCost)
            AS ProcurementValue

    FROM Suppliers AS s

    INNER JOIN PurchaseOrders AS po
        ON s.SupplierID = po.SupplierID

    INNER JOIN PurchaseOrderLines AS pol
        ON po.POID = pol.POID

    INNER JOIN Materials AS m
        ON pol.MaterialID = m.MaterialID

    WHERE s.SupplierType = 'Dairy Farm'
      AND m.MaterialCategory = 'Raw Milk'
      AND po.PODate >= '2026-01-01'
      AND po.PODate < '2027-01-01'

    GROUP BY
        s.SupplierID,
        s.SupplierName
),

DairyQuality AS
(
    SELECT
        s.SupplierID,

        COUNT(qi.InspectionID) AS TotalInspections,

        SUM(
            CASE
                WHEN qi.Result = 'Pass' THEN 1
                ELSE 0
            END
        ) AS PassedInspections,

        SUM(
            CASE
                WHEN qi.Result = 'Pass' THEN 1
                ELSE 0
            END
        ) * 100.0
        / NULLIF(COUNT(qi.InspectionID), 0)
            AS PassRatePct

    FROM Suppliers AS s

    INNER JOIN QualityInspections AS qi
        ON s.SupplierID = qi.SupplierID

    WHERE s.SupplierType = 'Dairy Farm'
      AND qi.InspectionType = 'IncomingMilk'

    GROUP BY
        s.SupplierID
)

SELECT
    dp.SupplierID,
    dp.SupplierName,
    dp.ProcurementValue,
    dq.TotalInspections,
    dq.PassedInspections,
    dq.PassRatePct

FROM DairyProcurement AS dp

INNER JOIN DairyQuality AS dq
    ON dp.SupplierID = dq.SupplierID

WHERE dp.ProcurementValue >
(
    SELECT AVG(ProcurementValue)
    FROM DairyProcurement
)
AND dq.PassRatePct >= 90

ORDER BY
    dp.ProcurementValue DESC









--IMPORTANT 5 QUESTIONS OF BUSSINIUS   
--Q1   سلامة سلسلة التبريد ومعدل مرتجعات الشحن للموزعين    

SELECT 
    d.DestinationGovernorate,
    d.DistributorName,
    COUNT(d.DispatchID) AS TotalDispatches,
    SUM(d.QuantityCases) AS TotalCasesSent,
    SUM(CASE WHEN d.DeliveryStatus IN ('Returned', 'RejectedAtDestination') THEN d.QuantityCases ELSE 0 END) AS RejectedCases,
    ROUND(SUM(CASE WHEN d.DeliveryStatus IN ('Returned', 'RejectedAtDestination') THEN d.QuantityCases ELSE 0 END) * 100.0 / SUM(d.QuantityCases), 2) AS RejectionRatePct,
    ROUND(AVG(d.DispatchTemperatureC), 1) AS AvgDispatchTempC,
    SUM(CASE WHEN d.DispatchTemperatureC > 8.0 THEN 1 ELSE 0 END) AS TempViolationCount
FROM Dispatches d
WHERE d.DispatchDateTime >= '2026-01-01' AND d.DispatchDateTime < '2027-01-01'
GROUP BY d.DestinationGovernorate, d.DistributorName
HAVING COUNT(d.DispatchID) >= 50
ORDER BY RejectionRatePct DESC, TempViolationCount DESC;

