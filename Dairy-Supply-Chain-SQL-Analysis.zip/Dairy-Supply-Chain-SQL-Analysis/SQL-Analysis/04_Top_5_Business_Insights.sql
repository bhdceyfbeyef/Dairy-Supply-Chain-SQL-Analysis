/*
NileCult Dairy Factory - Top 5 Business Insights
SQL Server | 2026 analysis

Run each query separately in DairySupplyChainDB.
The queries return the data needed to build the five business-insight visuals.
*/

USE DairySupplyChainDB;
GO

/* =========================================================
   BUSINESS INSIGHT 1 - Supplier Procurement Performance
   Business question:
   Which suppliers account for the highest procurement value in 2026?
   Note: Freight is aggregated separately to avoid multiplying
   each PO's freight cost by its number of purchase-order lines.
   ========================================================= */

WITH SupplierPOs AS
(
    SELECT
        po.SupplierID,
        COUNT(*) AS NumberOfPOs,
        AVG(CAST(po.FreightCost AS DECIMAL(18,2))) AS AverageFreightCost
    FROM PurchaseOrders AS po
    WHERE po.PODate >= '2026-01-01'
      AND po.PODate <  '2027-01-01'
    GROUP BY po.SupplierID
),
SupplierPurchases AS
(
    SELECT
        po.SupplierID,
        SUM(pol.OrderedQty * pol.UnitCost) AS TotalProcurementValue
    FROM PurchaseOrders AS po
    INNER JOIN PurchaseOrderLines AS pol
        ON pol.POID = po.POID
    WHERE po.PODate >= '2026-01-01'
      AND po.PODate <  '2027-01-01'
    GROUP BY po.SupplierID
)
SELECT
    s.SupplierCode,
    s.SupplierName,
    s.SupplierType,
    sp.NumberOfPOs,
    sp.TotalProcurementValue,
    spo.AverageFreightCost
FROM Suppliers AS s
INNER JOIN SupplierPOs AS spo
    ON spo.SupplierID = s.SupplierID
INNER JOIN SupplierPurchases AS sp
    ON sp.SupplierID = s.SupplierID
WHERE spo.NumberOfPOs >= 10
ORDER BY sp.TotalProcurementValue DESC;
GO


/* =========================================================
   BUSINESS INSIGHT 2 - Production Performance by Product Family
   Business question:
   Which product family delivered the highest production output
   in Q2 2026, and how much was rejected?
   ========================================================= */

SELECT
    p.ProductFamily,
    COUNT(pb.BatchID) AS TotalBatches,
    SUM(pb.PlannedQtyKg) AS TotalPlannedKg,
    SUM(pb.ActualQtyKg) AS TotalActualKg,
    SUM(pb.RejectQtyKg) AS TotalRejectKg,
    SUM(pb.ActualQtyKg) * 100.0
        / NULLIF(SUM(pb.PlannedQtyKg), 0) AS YieldPct,
    SUM(pb.RejectQtyKg) * 100.0
        / NULLIF(SUM(pb.ActualQtyKg), 0) AS RejectRatePct
FROM ProductionBatches AS pb
INNER JOIN Products AS p
    ON p.ProductID = pb.ProductID
WHERE pb.ProductionDate >= '2026-04-01'
  AND pb.ProductionDate <  '2026-07-01'
GROUP BY p.ProductFamily
ORDER BY TotalActualKg DESC;
GO


/* =========================================================
   BUSINESS INSIGHT 3 - Raw Milk Supplier Quality
   Business question:
   Which dairy-farm suppliers have the highest incoming-milk
   failure rates in 2026?
   ========================================================= */

SELECT
    s.SupplierCode,
    s.SupplierName,
    COUNT(qi.InspectionID) AS TotalInspections,
    SUM(CASE WHEN qi.Result = 'Fail' THEN 1 ELSE 0 END)
        AS FailedInspections,
    SUM(CASE WHEN qi.Result = 'Hold' THEN 1 ELSE 0 END)
        AS HoldInspections,
    SUM(CASE WHEN qi.Result = 'Pass' THEN 1 ELSE 0 END)
        AS PassedInspections,
    SUM(CASE WHEN qi.Result = 'Fail' THEN 1 ELSE 0 END) * 100.0
        / NULLIF(COUNT(qi.InspectionID), 0) AS FailRatePct,
    AVG(qi.TemperatureC) AS AverageTemperatureC,
    AVG(CAST(qi.BacteriaCountCFU AS DECIMAL(18,2)))
        AS AverageBacteriaCountCFU
FROM Suppliers AS s
INNER JOIN QualityInspections AS qi
    ON qi.SupplierID = s.SupplierID
WHERE s.SupplierType = 'Dairy Farm'
  AND qi.InspectionType = 'IncomingMilk'
  AND qi.InspectionDateTime >= '2026-01-01'
  AND qi.InspectionDateTime <  '2027-01-01'
GROUP BY
    s.SupplierCode,
    s.SupplierName
HAVING COUNT(qi.InspectionID) >= 100
ORDER BY FailRatePct DESC;
GO


/* =========================================================
   BUSINESS INSIGHT 4 - Monthly Production Trends
   Business question:
   Which months in 2026 exceeded the average monthly actual
   production output?
   ========================================================= */

WITH MonthlyProduction AS
(
    SELECT
        DATEFROMPARTS(YEAR(ProductionDate), MONTH(ProductionDate), 1)
            AS MonthStart,
        COUNT(BatchID) AS BatchCount,
        SUM(PlannedQtyKg) AS TotalPlannedKg,
        SUM(ActualQtyKg) AS TotalActualKg,
        SUM(RejectQtyKg) AS TotalRejectKg
    FROM ProductionBatches
    WHERE ProductionDate >= '2026-01-01'
      AND ProductionDate <  '2027-01-01'
    GROUP BY
        YEAR(ProductionDate),
        MONTH(ProductionDate)
),
MonthlyBenchmark AS
(
    SELECT
        *,
        AVG(CAST(TotalActualKg AS DECIMAL(18,2))) OVER ()
            AS AverageMonthlyActualKg
    FROM MonthlyProduction
)
SELECT
    MonthStart,
    BatchCount,
    TotalPlannedKg,
    TotalActualKg,
    TotalRejectKg,
    AverageMonthlyActualKg,
    TotalActualKg - AverageMonthlyActualKg
        AS AboveAverageKg
FROM MonthlyBenchmark
WHERE TotalActualKg > AverageMonthlyActualKg
ORDER BY MonthStart;
GO


/* =========================================================
   BUSINESS INSIGHT 5 - Purchased vs Consumed Material Balance
   Business question:
   Which materials were consumed in greater quantities than
   the quantities received during 2026?
   ========================================================= */

WITH MaterialReceipts AS
(
    SELECT
        pol.MaterialID,
        SUM(pol.ReceivedQty) AS ReceivedQty
    FROM PurchaseOrderLines AS pol
    INNER JOIN PurchaseOrders AS po
        ON po.POID = pol.POID
    WHERE po.PODate >= '2026-01-01'
      AND po.PODate <  '2027-01-01'
      AND pol.LineStatus <> 'Cancelled'
    GROUP BY pol.MaterialID
),
MaterialConsumption AS
(
    SELECT
        bmu.MaterialID,
        SUM(bmu.ActualQty) AS UsedQty
    FROM BatchMaterialUsage AS bmu
    INNER JOIN ProductionBatches AS pb
        ON pb.BatchID = bmu.BatchID
    WHERE pb.ProductionDate >= '2026-01-01'
      AND pb.ProductionDate <  '2027-01-01'
    GROUP BY bmu.MaterialID
),
MaterialBalance AS
(
    SELECT
        m.MaterialCode,
        m.MaterialName,
        m.MaterialCategory,
        COALESCE(mr.ReceivedQty, 0) AS ReceivedQty,
        COALESCE(mc.UsedQty, 0) AS UsedQty,
        COALESCE(mr.ReceivedQty, 0) - COALESCE(mc.UsedQty, 0)
            AS NetBalanceQty,
        COALESCE(mc.UsedQty, 0) * 100.0
            / NULLIF(COALESCE(mr.ReceivedQty, 0), 0)
            AS UsageToReceiptPct
    FROM Materials AS m
    LEFT JOIN MaterialReceipts AS mr
        ON mr.MaterialID = m.MaterialID
    LEFT JOIN MaterialConsumption AS mc
        ON mc.MaterialID = m.MaterialID
),
RankedShortages AS
(
    SELECT
        *,
        RANK() OVER (ORDER BY NetBalanceQty ASC) AS ShortageRank
    FROM MaterialBalance
    WHERE UsedQty > ReceivedQty
)
SELECT
    MaterialCode,
    MaterialName,
    MaterialCategory,
    ReceivedQty,
    UsedQty,
    NetBalanceQty,
    UsageToReceiptPct,
    ShortageRank
FROM RankedShortages
ORDER BY ShortageRank, MaterialName;
GO
